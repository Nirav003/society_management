from django.db import models

# Create your models here.
class users(models.Model):
    name=models.CharField(max_length=50)
    email=models.EmailField()
    password=models.CharField()
    is_active=models.BooleanField(default=True)
    role=models.CharField(default='Tenant')
    
    def __str__(self):
        name = self.name
    
class maintenance_bills(models.Model):
    flat=models.IntegerField()
    month=models.CharField(max_length=50)
    amount=models.DecimalField(decimal_places=2, max_digits=5)
    status=models.CharField()

class society_details(models.Model):
    society_name=models.CharField(max_length=100)
    society_address=models.TextField(max_length=250)
    flat_number=models.IntegerField()
    assigned_owner=models.CharField()