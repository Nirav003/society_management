from serializers import serializers
from models import users

def AdminSerializer(serializers.ModelSerializer):
    user = users.objects.all()
    serialize_data = serializers(user)
    return serialize_data