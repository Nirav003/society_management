from django.urls import path
from . import views

urlpatterns = [
    path('admin/', views.Admin),
    path('owner/', views.Owner),
    path('tenant/', views.Tenant)
]