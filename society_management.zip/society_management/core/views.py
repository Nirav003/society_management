from django.http import HttpResponse

# Create your views here.
def Admin(request):
    return HttpResponse('Admin Dashboard!!!')

def Owner(request):
    return HttpResponse('Owner Dashboard!!!')

def Tenant(request):
    return HttpResponse('Tenant Dashboard!!!')
